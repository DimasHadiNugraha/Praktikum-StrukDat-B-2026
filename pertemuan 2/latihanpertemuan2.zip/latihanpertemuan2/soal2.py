'''2. Diberikan sebuah tuple data mahasiswa:
mahasiswa = ("A001", "Budi", "Informatika")
1. Tampilkan nama mahasiswa dari tuple tersebut.
2. Tampilkan seluruh isi tuple menggunakan perulangan for.
3. Jelaskan satu alasan mengapa tuple tidak bisa diubah.'''

#1
thistupl = ("A001", "Budi", "Informatika")
print("Budi")

#2
thistuple = ("A001", "Budi", "Informatika")
for x in thistuple:
  print(x)

#3
'''karna bersifat unchangeable'''